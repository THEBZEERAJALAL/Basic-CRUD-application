from django.apps import AppConfig


class EmployeeInfoConfig(AppConfig):
    name = 'employee_info'
