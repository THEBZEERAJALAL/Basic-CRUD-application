from django.contrib.auth.mixins import LoginRequiredMixin,UserPassesTestMixin
from django.shortcuts import render
from .models import Post
from  django.views.generic import ListView,CreateView,DeleteView

def front(request):
    return render(request,'employee_info/front.html')

def create_user_profile(request):
    return render(request,'employee_info/create.html')






class PostListView(ListView):
    model = Post
    template_name = 'employee_info/edit.html'
    context_object_name = 'posts'

class postDetailView(DeleteView):
    model = Post
    # print("---------------------------------------------------+++++++++++++++++++++++++++++++")


class postCreateView(CreateView):
    model = Post
    fields = ['secondname','firstname']
    template_name = 'employee_info/post_create.html'

    def form_valid(self, form):
        return super().form_valid(form)

class postDeleteView(LoginRequiredMixin,UserPassesTestMixin, DeleteView):
    model = Post

def delete(request):
    return render(request,'employee_info/delete.html')

def view(request):
    return render(request,'employee_info/view.html')


