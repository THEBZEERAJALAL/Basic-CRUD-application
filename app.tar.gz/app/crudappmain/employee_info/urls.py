from django.conf.urls import url
from . import views
from .views import PostListView,postDetailView,postCreateView,postDeleteView

urlpatterns = [

    url(r'^post/int:<pk>/', postDeleteView.as_view(), name='post-delete'),
    url(r'^create/', postCreateView.as_view(), name='post-create'),
    url(r'^post/<int:pk>/',postDetailView.as_view(),name='post-details'),
    ###url(r'^create/', views.create_user_profile ),
    url(r'^edit/', views.view),
    url(r'^viewall/', PostListView.as_view(),name="Employee-edit"),
    url(r'^delete/', views.delete),
    url(r'^', views.front , name='Blog About'),
    #### url('front/', views.front , name='Blog About'),


    # url('', views.home, name='Blog Name'),

]