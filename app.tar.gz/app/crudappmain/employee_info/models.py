from django.db import models
# from rest_framework import serializer
from django.urls import reverse

# Create your models here.

# class employee()

class Post(models.Model):
    # id =models.IntegerField(primary_key=)
    firstname=models.CharField(max_length=100)
    secondname=models.CharField(max_length=30)

    def __str__(self):
        return self.firstname

    def get_absolute_url(self):
        return reverse('Employee-edit')

